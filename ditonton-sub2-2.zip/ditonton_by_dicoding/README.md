# Ditonton By Dicoding

[![Codemagic build status](https://api.codemagic.io/apps/61a4f406cc65be06e9c19d24/61a4f406cc65be06e9c19d23/status_badge.svg)](https://codemagic.io/apps/61a4f406cc65be06e9c19d24/61a4f406cc65be06e9c19d23/latest_build)