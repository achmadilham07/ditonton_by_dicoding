enum RequestState { empty, loading, loaded, error }
